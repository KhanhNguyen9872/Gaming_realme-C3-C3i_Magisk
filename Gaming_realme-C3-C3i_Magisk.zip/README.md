# Gaming Module for realme C3/C3i
- Free up your RAM and force CPU Performance
# Required Root Magisk v20.0 or up
- Cannot installed in old version magisk than v20.0
# Only for realmeUI 1.0 (ColorOS 7/Android 10) and EU rom!
- RMX2020, RMX2021, RMX2022, RMX2027 running ROM Stock or EU Rom (realmeUI 1.0)
# NOT FOR CUSTOM ROM AND REALMEUI 2.0
- Not supported realmeUI 2.0 and EU ROM realmeUI 2.0
# FLASH IN UNSUPPORTED DEVICE OR ROM MAY GET BRICKED!!
- Very dangerous if you install on unsupported rom MediaTek
